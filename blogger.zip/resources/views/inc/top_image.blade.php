<div class="top-image"
    style="background:linear-gradient(rgba(0, 0, 0, 0.45),rgba(0, 0, 0, 0.45)),url({{asset('img/slide-1.jpg')}})">
    {{-- @yield('page-name') --}}
</div>