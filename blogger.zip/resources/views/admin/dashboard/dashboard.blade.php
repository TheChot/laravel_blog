@extends('admin.layouts.main')

@section('content')
im the dash

@endsection