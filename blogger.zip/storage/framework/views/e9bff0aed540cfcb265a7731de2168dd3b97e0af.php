<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Service Inquiry Email</title>
</head>

<body>

    <h2>Good day, You have a Service Inquiry from your app</h2>
    <h3>From: <?php echo e($name); ?>, <?php echo e($title); ?></h3>
    <h3>Phone Number: <?php echo e($phone_number); ?></h3>
    <h3>Email: <?php echo e($email); ?></h3>
    <h3>Service Requested: <?php echo e($service); ?></h3>
    <h3>No. of Rooms: <?php echo e($no_rooms); ?></h3>
    <h3>Unit Space: <?php echo e($unit_space); ?></h3>
    <h3>Details: <?php echo e($details); ?></h3>


</body>

</html><?php /**PATH C:\xampp\htdocs\blogger\resources\views/emails/inquiryemail.blade.php ENDPATH**/ ?>