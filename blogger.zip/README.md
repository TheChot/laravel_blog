## Laravel Blog Starter

A single user blogging application to serve as a starting template
